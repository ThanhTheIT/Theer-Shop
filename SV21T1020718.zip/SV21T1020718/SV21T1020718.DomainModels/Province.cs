﻿namespace SV21T1020718.DomainModels
{
    public class Province
    {
        public String ProvinceName { get; set; } = string.Empty;
    }
}