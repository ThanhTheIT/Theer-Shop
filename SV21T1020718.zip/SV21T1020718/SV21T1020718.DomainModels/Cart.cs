﻿namespace SV21T1020718.DomainModels
{
	public class Cart
	{
		public int CartId { get; set; }
		public int Sum { get; set; }
		public int CustomerID { get; set; }
	}
}